<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center">Dashboard</div>

                <div class="card-body text-center">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="title">
                        <h2>Welcome Back!</h2>
                        <p>You've successfully logged in.</p>
                    </div>

                    <div class="links">
                        <a href="<?php echo e(route('customers')); ?>" class="btn btn-primary btn-lg">Go To Customer Details</a>
                    </div>

                    <!-- Redirect to Customers after 3 seconds -->
                    <script>
                        setTimeout(function() {
                            window.location.href = "<?php echo e(route('customers')); ?>";
                        }, 5000);
                    </script>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>