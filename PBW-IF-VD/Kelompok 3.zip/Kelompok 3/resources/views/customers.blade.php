@extends('layouts.app')

@section('content')
<div class="container">
    <customer-component></customer-component>
</div>
@endsection
