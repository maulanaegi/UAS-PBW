<x-auth-layout title="Log In" authTitle="Welcome Back!" authSubtitle="Log in using your credentials to continue.">
    <x-slot name="authFooter">
        <div class="text-center mt-4">
            <p class="text-muted">Don't have an account? <a href="{{ route('register') }}" class="text-primary">Sign up here</a></p>
        </div>
    </x-slot>

    <form action="{{ route('login') }}" method="POST" class="p-4 rounded shadow-sm bg-white">
        @csrf
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="email" name="email" class="form-control form-control-lg @error('email') is-invalid @enderror"
                value="{{ old('email') }}" required placeholder="Email address" />
            <div class="form-control-icon">
                <i class="bi bi-envelope-fill"></i>
            </div>
            <x-invalid-feedback :message="$errors->first('email')"></x-invalid-feedback>
        </div>

        <div class="form-group position-relative has-icon-left mb-4">
            <input type="password" name="password"
                class="form-control form-control-lg @error('password') is-invalid @enderror"
                value="{{ old('password') }}" placeholder="Enter your password" required />
            <div class="form-control-icon">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
            <x-invalid-feedback :message="$errors->first('password')"></x-invalid-feedback>
        </div>

        <div class="d-flex justify-content-between mb-4">
            <div>
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="remember" id="remember">
                    Remember Me
                </label>
            </div>
            </div>

        <button type="submit" class="btn btn-primary btn-lg btn-block shadow-lg mt-4">
            Log in
        </button>
    </form>

    <x-slot name="authFooter">
        <div class="text-center mt-5">
            <p class="text-muted">By logging in, you agree to our <a href="{{ route('register') }}" class="text-primary">Register</a>.</p>
        </div>
    </x-slot>
</x-auth-layout>
