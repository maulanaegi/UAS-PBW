<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}"> <!-- Tambahkan link ke file CSS -->
</head>
<body>
    <header>
        <h1>Selamat Datang di Halaman Home</h1>
        <nav>
            <a href="{{ route('home') }}">Home</a>
            <a href="{{ route('login') }}">Login</a>
        </nav>
    </header>

    <main>
        <!-- Seksi Jurusan -->
        <section>
        <h1>Daftar Jurusan</h1>
        <ul>
    @foreach ($jurusan as $item)
        <li>{{ $item->jurusan }}</li>
    @endforeach
</ul>


        </section>

        <!-- Seksi UKM -->
<section>
    <h2>Unit Kegiatan Mahasiswa (UKM)</h2>
    <ul>
        @foreach ($ukm as $item)
            <li>{{ $item->nama }}</li>
        @endforeach
    </ul>
</section>


        <!-- Kontak -->
        <section>
            <h2>Kontak</h2>
            <p>Untuk informasi lebih lanjut, hubungi kami:</p>
            <ul>
                <li>Email: info@website.com</li>
                <li>Telepon: +62 812 3456 7890</li>
                <li>Alamat: Jalan Menuju Sukses No. 1, Indonesia</li>
            </ul>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Kelompok Pengembang</p>
    </footer>
</body>
</html>
