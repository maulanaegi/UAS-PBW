<div class="invalid-feedback">
    <i class="bx bx-radio-circle"></i>
    {{ $message }}
</div>
