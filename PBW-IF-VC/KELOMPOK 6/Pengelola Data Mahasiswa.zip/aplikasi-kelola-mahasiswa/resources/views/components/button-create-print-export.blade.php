<a href="{{ $routeTambah }}" class="btn btn-primary mb-3 d-block-inline" type="button">
    Tambah Data
</a>
<a href="{{ $routePrint }}" class="btn btn-secondary mb-3 d-block-inline" type="button">
    Print Data
</a>
<a href="{{ $routeExport }}" class="btn btn-secondary mb-3 d-block-inline" type="button">
    Export Data
</a>
