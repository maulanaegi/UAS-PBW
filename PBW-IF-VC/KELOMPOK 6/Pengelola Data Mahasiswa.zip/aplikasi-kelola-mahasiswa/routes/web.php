<?php

use App\Http\Controllers\AnggotaUKMController;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\UnitKegiatanMahasiswaController;
use App\Models\AnggotaUKM;
use App\Models\Mahasiswa;
use App\Models\UnitKegiatanMahasiswa;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route Home: Tampilan Dashboard
Route::get('/', function () {
    return view('dashboard', [
        'mahasiswa' => Mahasiswa::count(),
        'unit_kegiatan_mahasiswa' => UnitKegiatanMahasiswa::count(),
        'anggota_ukm' => AnggotaUKM::count(),
        'name' => auth()->check() ? auth()->user()->name : 'Guest', // Nama pengguna jika login
        'email' => auth()->check() ? auth()->user()->email : 'guest@example.com', // Email pengguna jika login
    ]);
});

// Group Route dengan Middleware 'auth'
Route::middleware('auth')->group(function () {
    // Route Mahasiswa
    Route::resource('mahasiswa', MahasiswaController::class)->except(['show']);
    Route::get('mahasiswa/export/pdf', [MahasiswaController::class, 'exportPdf'])->name('mahasiswa.pdf');
    Route::get('mahasiswa/export/excel', [MahasiswaController::class, 'exportExcel'])->name('mahasiswa.excel');

    // Route Unit Kegiatan Mahasiswa
    Route::resource('unit_kegiatan_mahasiswa', UnitKegiatanMahasiswaController::class)->except(['show']);
    Route::get('unit_kegiatan_mahasiswa/export/pdf', [UnitKegiatanMahasiswaController::class, 'exportPdf'])->name('unit_kegiatan_mahasiswa.pdf');
    Route::get('unit_kegiatan_mahasiswa/export/excel', [UnitKegiatanMahasiswaController::class, 'exportExcel'])->name('unit_kegiatan_mahasiswa.excel');

    // Route Anggota UKM
    Route::resource('anggota_ukm', AnggotaUKMController::class)->except(['show']);
    Route::get('anggota_ukm/export/pdf', [AnggotaUKMController::class, 'exportPdf'])->name('anggota_ukm.pdf');
    Route::get('anggota_ukm/export/excel', [AnggotaUKMController::class, 'exportExcel'])->name('anggota_ukm.excel');
});
