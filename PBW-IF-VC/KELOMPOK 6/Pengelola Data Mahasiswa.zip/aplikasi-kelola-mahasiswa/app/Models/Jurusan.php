<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jurusan extends Model
{
    use HasFactory;

    // Tentukan nama tabel jika berbeda dengan nama model
    protected $table = 'jurusan';

    // Tentukan kolom yang bisa diisi
    protected $fillable = ['jurusan'];

    // Jika model memiliki relasi dengan model lain, bisa didefinisikan di sini
}
