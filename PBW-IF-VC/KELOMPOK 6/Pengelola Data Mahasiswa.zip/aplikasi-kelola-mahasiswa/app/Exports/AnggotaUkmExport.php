<?php

namespace App\Exports;

use App\Models\AnggotaUKM;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithTitle;

class AnggotaUKMExport implements FromCollection, WithHeadings, WithMapping, WithTitle
{
    /**
     * Retrieve all AnggotaUKM records.
     *
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return AnggotaUKM::with(['mahasiswa', 'ukm'])->get();
    }

    /**
     * Define headings for the exported Excel file.
     * 
     * @return array
     */
    public function headings(): array
    {
        return [
            'ID',
            'NIM',
            'Nama Mahasiswa',
            'Nama UKM',
            'Tanggal Bergabung',
        ];
    }

    /**
     * Map the data for each row in the Excel file.
     *
     * @param AnggotaUKM $anggotaUKM
     * @return array
     */
    public function map($anggotaUKM): array
    {
        return [
            $anggotaUKM->id,
            $anggotaUKM->mahasiswa->NIM ?? 'N/A', // Handle null values gracefully
            $anggotaUKM->mahasiswa->name ?? 'N/A',
            $anggotaUKM->ukm->name ?? 'N/A',
            $anggotaUKM->created_at->format('d-m-Y'),
        ];
    }

    /**
     * Title for the sheet.
     *
     * @return string
     */
    public function title(): string
    {
        return 'Anggota UKM';
    }
}
