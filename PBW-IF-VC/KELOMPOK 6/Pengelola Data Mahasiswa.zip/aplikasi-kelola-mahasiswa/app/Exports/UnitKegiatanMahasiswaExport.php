<?php

namespace App\Exports;

use App\Models\UnitKegiatanMahasiswa;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Font;

class UnitKegiatanMahasiswaExport implements FromCollection, WithHeadings, WithStyles, WithColumnFormatting
{
    /**
     * @return \Illuminate\Support\Collection
     */
    public function collection()
    {
        return UnitKegiatanMahasiswa::all();
    }

    /**
     * Define the headings for the exported file.
     *
     * @return array
     */
    public function headings(): array
    {
        return [
            'No.',
            'Nama UKM',
            'Deskripsi',
            'Tanggal Dibuat',
        ];
    }

    /**
     * Apply custom styles to the exported data.
     *
     * @param \PhpOffice\PhpSpreadsheet\Worksheet $sheet
     */
    public function styles($sheet)
    {
        // Apply bold and center alignment for the headings
        $sheet->getStyle('A1:D1')->getFont()->setBold(true);
        $sheet->getStyle('A1:D1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        // Apply column width
        $sheet->getColumnDimension('A')->setWidth(5);
        $sheet->getColumnDimension('B')->setWidth(25);
        $sheet->getColumnDimension('C')->setWidth(40);
        $sheet->getColumnDimension('D')->setWidth(20);

        return [
            // Apply text wrap for the description column
            'C' => ['alignment' => ['wrapText' => true]],
        ];
    }

    /**
     * Format specific columns.
     *
     * @return array
     */
    public function columnFormats(): array
    {
        return [
            'D' => \PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_DATE_DDMMYYYY, // Format date column
        ];
    }
}
