<?php

namespace App\Exports;

use App\Models\Mahasiswa;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\WithTitle;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class MahasiswaExport implements FromCollection, WithHeadings, WithMapping, WithStyles, WithTitle
{
    public function collection()
    {
        return Mahasiswa::all();
    }

    public function headings(): array
    {
        return [
            'ID',
            'NIM',
            'Nama Mahasiswa',
            'Tanggal Ditambahkan',
        ];
    }

    public function map($mahasiswa): array
    {
        return [
            $mahasiswa->id,
            $mahasiswa->NIM,
            $mahasiswa->name,
            $mahasiswa->created_at->format('d-m-Y H:i:s'),
        ];
    }

    // Styling the table
    public function styles(Worksheet $sheet)
    {
        // Apply bold to the headings
        $sheet->getStyle('A1:D1')->getFont()->setBold(true);
        
        // Set background color for the header row
        $sheet->getStyle('A1:D1')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
        $sheet->getStyle('A1:D1')->getFill()->getStartColor()->setARGB('FFFF00'); // Yellow
        
        // Set column width for better visibility
        $sheet->getColumnDimension('A')->setWidth(10);
        $sheet->getColumnDimension('B')->setWidth(15);
        $sheet->getColumnDimension('C')->setWidth(25);
        $sheet->getColumnDimension('D')->setWidth(20);
        
        // Align columns to center
        $sheet->getStyle('A:D')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
        
        // Add borders around cells
        $sheet->getStyle('A1:D' . (count($this->collection()) + 1))
              ->getBorders()
              ->getAllBorders()
              ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

        return [
            // Set the font for all the cells
            'A1:D1' => ['font' => ['name' => 'Arial', 'size' => 12]],
            'A2:D' . (count($this->collection()) + 1) => ['font' => ['name' => 'Arial', 'size' => 10]],
        ];
    }

    // Set the sheet title (optional)
    public function title(): string
    {
        return 'Data Mahasiswa';
    }
}
