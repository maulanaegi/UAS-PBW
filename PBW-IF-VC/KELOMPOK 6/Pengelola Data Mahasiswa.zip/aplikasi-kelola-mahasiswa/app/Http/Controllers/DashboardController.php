<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function dashboard() {
        $user = auth()->user(); // Assuming you're using Laravel's authentication
        return view('dashboard', ['name' => $user->name, 'email' => $user->email]);
    }
    
}

