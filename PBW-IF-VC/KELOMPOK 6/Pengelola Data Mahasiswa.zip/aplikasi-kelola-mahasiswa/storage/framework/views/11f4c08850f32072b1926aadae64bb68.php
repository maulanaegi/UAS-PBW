<div class="<?php echo e($col); ?>">
    <div class="card">
        <div class="card-body px-4 py-4-5">
            <div class="row">
                <div class="col-md-4 col-lg-12 col-xl-12 col-xxl-5 d-flex justify-content-start">
                    <div class="stats-icon <?php echo e($color); ?> mb-2">
                        <?php echo e($slot); ?>

                    </div>
                </div>
                <div class="col-md-8 col-lg-12 col-xl-12 col-xxl-7">
                    <h6 class="text-muted font-semibold">
                        <?php echo e($title); ?>

                    </h6>
                    <h6 class="font-extrabold mb-0"><?php echo e($number); ?></h6>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/card-with-icon.blade.php ENDPATH**/ ?>