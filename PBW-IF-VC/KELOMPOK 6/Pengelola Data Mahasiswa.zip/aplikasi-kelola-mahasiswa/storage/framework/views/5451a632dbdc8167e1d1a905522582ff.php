<div class="alert alert-<?php echo e($type); ?>">
    <h4 class="alert-heading">
        <?php echo e($title); ?>

    </h4>
    <p>
        <?php echo e($slot); ?>

    </p>
</div>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/alert-heading.blade.php ENDPATH**/ ?>