<?php if (isset($component)) { $__componentOriginala6488acc797ee40bc55ed6344dee8ea1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1 = $attributes; } ?>
<?php $component = App\View\Components\AuthLayout::resolve(['title' => 'Sign Up','authTitle' => 'Sign Up','authSubtitle' => 'Input your data to register to our website.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AuthLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('authFooter', null, []); ?> 
        <p class="text-gray-600">
            Already have an account?
            <a href="<?php echo e(route('login')); ?>" class="font-bold">Log in</a>.
        </p>
     <?php $__env->endSlot(); ?>
    <form action="<?php echo e(route('register')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="text" name="email" class="form-control form-control-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Email" />
            <div class="form-control-icon">
                <i class="bi bi-envelope"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('email'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="text" name="name"
                class="form-control form-control-xl <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Username" />
            <div class="form-control-icon">
                <i class="bi bi-person"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('name'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="password" name="password"
                class="form-control form-control-xl  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" />
            <div class="form-control-icon">
                <i class="bi bi-shield-lock"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="password" name="password_confirmation"
                class="form-control form-control-xl <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Confirm Password" />
            <div class="form-control-icon">
                <i class="bi bi-shield-lock"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>
        <button class="btn btn-primary btn-block btn-lg shadow-lg mt-5">
            Sign Up
        </button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $attributes = $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $component = $__componentOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/auth/register.blade.php ENDPATH**/ ?>