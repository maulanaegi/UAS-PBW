<header>
    <nav class="navbar navbar-expand navbar-light navbar-top">
        <div class="container-fluid">
            <!-- Burger Button -->
            <a href="#" class="burger-btn d-block">
                <i class="bi bi-justify fs-3"></i>
            </a>

            <!-- Navbar Toggler -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Links -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-lg-0">
                    <!-- Add navbar links here if needed -->
                </ul>

                <!-- Left Side: Date -->
                <div class="d-flex align-items-center mx-3">
                    <i class="bi bi-calendar-week fs-4 text-primary"></i>
                    <span id="current-date" class="ms-2 text-sm text-gray-600"></span>
                </div>

                <!-- Centered Text: "Aplikasi Pengelola Mahasiswa" -->
                <div class="d-flex justify-content-center align-items-center flex-grow-1">
                    <span class="navbar-text text-center" style="font-size: 1.5rem; font-family: 'Arial', sans-serif; font-weight: bold;">
                        Aplikasi Pengelola Mahasiswa
                    </span>
                </div>

                <!-- User Dropdown -->
                <div class="dropdown ms-3">
                    <a href="#" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="user-menu d-flex">
                            <div class="user-name text-end me-3">
                                <?php if(Auth::check()): ?>
                                    <p class="mb-0 text-sm text-gray-600"><?php echo e($name); ?></p>
                                    <p class="mb-0 text-sm text-gray-600"><?php echo e(Auth::user()->email); ?></p>
                                    <p class="mb-0 text-sm text-gray-600">ID: <?php echo e(Auth::user()->id); ?></p>
                                <?php else: ?>
                                    <p class="mb-0 text-sm text-gray-600">Guest</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton" style="min-width: 11rem;">
                        <li>
                            <h6 class="dropdown-header">Hello, <?php echo e($name); ?></h6>
                        </li>
                        <hr class="dropdown-divider">
                        <li>
                            <?php if(auth()->guard()->check()): ?>
                                <form action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item" type="submit">
                                        <i class="icon-mid bi bi-box-arrow-left me-2"></i> Logout
                                    </button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('login')); ?>" method="GET">
                                    <button class="dropdown-item" type="submit">
                                        <i class="icon-mid bi bi-box-arrow-left me-2"></i> Login
                                    </button>
                                </form>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>

                <!-- User Avatar -->
                <div class="user-img d-flex align-items-center ms-3">
                    <div class="avatar avatar-md">
                        <img src="<?php echo e(asset('assets/images/faces/2.jpg')); ?>" alt="User Avatar">
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

<script>
    // Function to display the current date in the format: Day, Month Date, Year
    function updateDate() {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const currentDate = new Date().toLocaleDateString('id-ID', options); // Indonesian locale
        document.getElementById('current-date').innerText = currentDate;
    }

    // Call the function when the page loads
    window.onload = () => {
        updateDate();
    };
</script>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/layouts/app/navbar.blade.php ENDPATH**/ ?>