<table class="table table-striped" id="table1">
    <thead>
        <tr>
            <th>No</th>
            <?php echo e($column); ?>

        </tr>
    </thead>
    <tbody>
        <?php echo e($slot); ?>

    </tbody>
</table>

<?php $__env->startPush('library-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extension/simple-datatables/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/table-datatable.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('library-js'); ?>
    <script src="<?php echo e(asset('assets/extension/simple-datatables/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/table.blade.php ENDPATH**/ ?>