<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> <!-- Tambahkan link ke file CSS -->
</head>
<body>
    <header>
        <h1>Selamat Datang di Halaman Home</h1>
        <nav>
            <a href="<?php echo e(route('home')); ?>">Home</a>
            <a href="<?php echo e(route('login')); ?>">Login</a>
        </nav>
    </header>

    <main>
        <!-- Seksi Jurusan -->
        <section>
        <h1>Daftar Jurusan</h1>
        <ul>
    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item->jurusan); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


        </section>

        <!-- Seksi UKM -->
<section>
    <h2>Unit Kegiatan Mahasiswa (UKM)</h2>
    <ul>
        <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($item->nama); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</section>


        <!-- Kontak -->
        <section>
            <h2>Kontak</h2>
            <p>Untuk informasi lebih lanjut, hubungi kami:</p>
            <ul>
                <li>Email: info@website.com</li>
                <li>Telepon: +62 812 3456 7890</li>
                <li>Alamat: Jalan Menuju Sukses No. 1, Indonesia</li>
            </ul>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Kelompok Pengembang</p>
    </footer>
</body>
</html>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/mahasiswa/home.blade.php ENDPATH**/ ?>