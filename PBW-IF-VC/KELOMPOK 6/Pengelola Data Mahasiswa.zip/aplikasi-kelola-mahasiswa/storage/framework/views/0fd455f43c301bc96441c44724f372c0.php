<form action="<?php echo e($route); ?>" method="<?php echo e($method); ?>" class="form">
    <?php echo method_field($overrideMethod ?? null); ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <?php echo e($slot); ?>

        <div class="col-12 d-flex justify-content-end">
            <button type="submit" class="btn btn-primary me-1 mb-1">
                Submit
            </button>
            <button type="reset" class="btn btn-light-secondary me-1 mb-1">
                Reset
            </button>
        </div>
    </div>
</form>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/form.blade.php ENDPATH**/ ?>