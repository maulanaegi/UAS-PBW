<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3><?php echo e($title); ?></h3>
                <p class="text-subtitle text-muted">
                    <?php echo e($subtitle); ?>

                </p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <?php echo e($slot); ?>

                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/page-heading.blade.php ENDPATH**/ ?>