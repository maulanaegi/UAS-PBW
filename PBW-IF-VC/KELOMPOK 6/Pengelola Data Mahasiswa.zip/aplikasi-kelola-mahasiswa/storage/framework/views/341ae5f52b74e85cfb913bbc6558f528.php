<?php $__env->startPush('library-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/extension/sweet-alerts/sweetalert2.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('library-js'); ?>
    <script src="<?php echo e(asset('assets/extension/sweet-alerts/sweetalert2.min.js')); ?>"></script>

    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        const session = <?php echo json_encode(session()->all(), 15, 512) ?>;
        if (session.success) {
            Toast.fire({
                icon: 'success',
                title: session.success
            })
        } else if (session.error) {
            Toast.fire({
                icon: 'error',
                title: session.error
            })
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/sa-warning.blade.php ENDPATH**/ ?>