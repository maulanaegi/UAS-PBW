<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>FTI &copy; 2024</p>
        </div>
        <div class="float-end">
            <p>
                Crafted with
                <span class="text-danger"><i class="bi bi-heart-fill icon-mid"></i></span>
                by <a href="" target="_blank">UNSAP</a>
            </p>
        </div>
    </div>
</footer>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/layouts/app/footer.blade.php ENDPATH**/ ?>