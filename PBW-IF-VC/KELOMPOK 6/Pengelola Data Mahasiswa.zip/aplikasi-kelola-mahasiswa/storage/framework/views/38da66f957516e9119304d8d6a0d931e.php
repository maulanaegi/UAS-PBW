<form action="<?php echo e($routeDelete); ?>" method="POST">
    <a href="<?php echo e($routeEdit); ?>" class="btn btn-warning btn-sm">
        <i class="bi bi-pencil"></i>
    </a>
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-danger btn-sm"
        onclick="return confirm('Apakah anda yakin ingin menghapus data ini?');">
        <i class="bi bi-trash"></i>
    </button>
</form>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/edit-delete-action.blade.php ENDPATH**/ ?>