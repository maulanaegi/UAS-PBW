<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Dashboard'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="page-content" style="min-height: 70vh">
        <?php if(auth()->guard()->check()): ?>
            <?php if (isset($component)) { $__componentOriginal039ca2c108bf0434d7e3c6a5f673c072 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal039ca2c108bf0434d7e3c6a5f673c072 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert-heading','data' => ['type' => 'primary','title' => ''.e(__('Welcome back, ' . $name)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'primary','title' => ''.e(__('Welcome back, ' . $name)).'']); ?>
                Bagaimana kabar anda hari ini?
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal039ca2c108bf0434d7e3c6a5f673c072)): ?>
<?php $attributes = $__attributesOriginal039ca2c108bf0434d7e3c6a5f673c072; ?>
<?php unset($__attributesOriginal039ca2c108bf0434d7e3c6a5f673c072); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal039ca2c108bf0434d7e3c6a5f673c072)): ?>
<?php $component = $__componentOriginal039ca2c108bf0434d7e3c6a5f673c072; ?>
<?php unset($__componentOriginal039ca2c108bf0434d7e3c6a5f673c072); ?>
<?php endif; ?>
        <?php endif; ?>
        <section class="row">
            <div class="col-12">
                <div class="row">
                    <?php if (isset($component)) { $__componentOriginale55713ebd265c5b643405a722c9942c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale55713ebd265c5b643405a722c9942c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-with-icon','data' => ['col' => 'col-12 col-lg-4 col-md-6','color' => 'purple','title' => 'Total Mahasiswa','number' => ''.e($mahasiswa).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-with-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'col-12 col-lg-4 col-md-6','color' => 'purple','title' => 'Total Mahasiswa','number' => ''.e($mahasiswa).'']); ?>
                        <i class="fas fa-users"></i>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $attributes = $__attributesOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__attributesOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $component = $__componentOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__componentOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale55713ebd265c5b643405a722c9942c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale55713ebd265c5b643405a722c9942c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-with-icon','data' => ['col' => 'col-12 col-lg-4 col-md-6','color' => 'green','title' => 'Total Unit Kegiatan Mahasiswa','number' => ''.e($unit_kegiatan_mahasiswa).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-with-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'col-12 col-lg-4 col-md-6','color' => 'green','title' => 'Total Unit Kegiatan Mahasiswa','number' => ''.e($unit_kegiatan_mahasiswa).'']); ?>
                        <i class="fa fa-store"></i>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $attributes = $__attributesOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__attributesOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $component = $__componentOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__componentOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginale55713ebd265c5b643405a722c9942c7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale55713ebd265c5b643405a722c9942c7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-with-icon','data' => ['col' => 'col-12 col-lg-4 col-md-4','color' => 'red','title' => 'Total Anggota UKM','number' => ''.e($anggota_ukm).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card-with-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['col' => 'col-12 col-lg-4 col-md-4','color' => 'red','title' => 'Total Anggota UKM','number' => ''.e($anggota_ukm).'']); ?>
                        <i class="fas fa-users"></i>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $attributes = $__attributesOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__attributesOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale55713ebd265c5b643405a722c9942c7)): ?>
<?php $component = $__componentOriginale55713ebd265c5b643405a722c9942c7; ?>
<?php unset($__componentOriginale55713ebd265c5b643405a722c9942c7); ?>
<?php endif; ?>
                </div>
            </div>
        </section>
        <?php $__env->startPush('spesific-css'); ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/extension/font-awesome/webfonts/font-awesome.css')); ?>">
        <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/dashboard.blade.php ENDPATH**/ ?>