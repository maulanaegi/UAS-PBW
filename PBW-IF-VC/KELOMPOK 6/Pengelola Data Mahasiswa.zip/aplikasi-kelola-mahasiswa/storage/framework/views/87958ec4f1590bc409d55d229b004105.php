<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => 'Unit Kegiatan Mahasiswa'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal8026f1991abb42645b4d7cc7ace47942 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8026f1991abb42645b4d7cc7ace47942 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.page-heading','data' => ['title' => 'Data Unit Kegiatan Mahasiswa','subtitle' => 'Halaman data unit kegiatan mahasiswa']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Unit Kegiatan Mahasiswa','subtitle' => 'Halaman data unit kegiatan mahasiswa']); ?>
        <li class="breadcrumb-item active" aria-current="page">Unit Kegiatan Mahasiswa</li>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8026f1991abb42645b4d7cc7ace47942)): ?>
<?php $attributes = $__attributesOriginal8026f1991abb42645b4d7cc7ace47942; ?>
<?php unset($__attributesOriginal8026f1991abb42645b4d7cc7ace47942); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8026f1991abb42645b4d7cc7ace47942)): ?>
<?php $component = $__componentOriginal8026f1991abb42645b4d7cc7ace47942; ?>
<?php unset($__componentOriginal8026f1991abb42645b4d7cc7ace47942); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal7b08d167d6a62f650d5e2a092984a448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b08d167d6a62f650d5e2a092984a448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-card','data' => ['title' => 'Data Unit Kegiatan Mahasiswa']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('section-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Unit Kegiatan Mahasiswa']); ?>
        <?php if (isset($component)) { $__componentOriginala2f962ef8b641a859f131e93aaa94101 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2f962ef8b641a859f131e93aaa94101 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button-create-print-export','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button-create-print-export'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('routeTambah', null, []); ?> <?php echo e(route('unit_kegiatan_mahasiswa.create')); ?> <?php $__env->endSlot(); ?>
             <?php $__env->slot('routePrint', null, []); ?> <?php echo e(route('unit_kegiatan_mahasiswa.pdf')); ?> <?php $__env->endSlot(); ?>
             <?php $__env->slot('routeExport', null, []); ?> <?php echo e(route('unit_kegiatan_mahasiswa.excel')); ?> <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2f962ef8b641a859f131e93aaa94101)): ?>
<?php $attributes = $__attributesOriginala2f962ef8b641a859f131e93aaa94101; ?>
<?php unset($__attributesOriginala2f962ef8b641a859f131e93aaa94101); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2f962ef8b641a859f131e93aaa94101)): ?>
<?php $component = $__componentOriginala2f962ef8b641a859f131e93aaa94101; ?>
<?php unset($__componentOriginala2f962ef8b641a859f131e93aaa94101); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('column', null, []); ?> 
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
             <?php $__env->endSlot(); ?>
            <?php $__currentLoopData = $unitKegiatanMahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($ukm->name); ?></td>
                    <td><?php echo e($ukm->description); ?></td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginal8215e51f53e63425d93c850e59cd66f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8215e51f53e63425d93c850e59cd66f7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-delete-action','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('edit-delete-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php $__env->slot('routeEdit', null, []); ?> <?php echo e(route('unit_kegiatan_mahasiswa.edit', $ukm->id)); ?> <?php $__env->endSlot(); ?>
                             <?php $__env->slot('routeDelete', null, []); ?> <?php echo e(route('unit_kegiatan_mahasiswa.destroy', $ukm->id)); ?> <?php $__env->endSlot(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8215e51f53e63425d93c850e59cd66f7)): ?>
<?php $attributes = $__attributesOriginal8215e51f53e63425d93c850e59cd66f7; ?>
<?php unset($__attributesOriginal8215e51f53e63425d93c850e59cd66f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8215e51f53e63425d93c850e59cd66f7)): ?>
<?php $component = $__componentOriginal8215e51f53e63425d93c850e59cd66f7; ?>
<?php unset($__componentOriginal8215e51f53e63425d93c850e59cd66f7); ?>
<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b08d167d6a62f650d5e2a092984a448)): ?>
<?php $attributes = $__attributesOriginal7b08d167d6a62f650d5e2a092984a448; ?>
<?php unset($__attributesOriginal7b08d167d6a62f650d5e2a092984a448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b08d167d6a62f650d5e2a092984a448)): ?>
<?php $component = $__componentOriginal7b08d167d6a62f650d5e2a092984a448; ?>
<?php unset($__componentOriginal7b08d167d6a62f650d5e2a092984a448); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal3ef7e0a3652949d86d02bc8397f73b25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ef7e0a3652949d86d02bc8397f73b25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sa-warning','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sa-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ef7e0a3652949d86d02bc8397f73b25)): ?>
<?php $attributes = $__attributesOriginal3ef7e0a3652949d86d02bc8397f73b25; ?>
<?php unset($__attributesOriginal3ef7e0a3652949d86d02bc8397f73b25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ef7e0a3652949d86d02bc8397f73b25)): ?>
<?php $component = $__componentOriginal3ef7e0a3652949d86d02bc8397f73b25; ?>
<?php unset($__componentOriginal3ef7e0a3652949d86d02bc8397f73b25); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/unit-kegiatan-mahasiswa/index.blade.php ENDPATH**/ ?>