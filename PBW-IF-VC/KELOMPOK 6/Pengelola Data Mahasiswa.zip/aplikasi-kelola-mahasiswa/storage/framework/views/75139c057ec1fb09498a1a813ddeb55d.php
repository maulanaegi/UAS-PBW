<div class="<?php echo e($col ?? 'col-12'); ?>">
    <div class="form-group">
        <?php echo e($label); ?>

        <?php echo e($slot); ?>

        <?php echo $__env->make('components.invalid-feedback', [
            'message' => $invalidFeedback ?? null,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/form-group.blade.php ENDPATH**/ ?>