<a href="<?php echo e($routeTambah); ?>" class="btn btn-primary mb-3 d-block-inline" type="button">
    Tambah Data
</a>
<a href="<?php echo e($routePrint); ?>" class="btn btn-secondary mb-3 d-block-inline" type="button">
    Print Data
</a>
<a href="<?php echo e($routeExport); ?>" class="btn btn-secondary mb-3 d-block-inline" type="button">
    Export Data
</a>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/button-create-print-export.blade.php ENDPATH**/ ?>