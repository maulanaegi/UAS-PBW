<div class="invalid-feedback">
    <i class="bx bx-radio-circle"></i>
    <?php echo e($message); ?>

</div>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/invalid-feedback.blade.php ENDPATH**/ ?>