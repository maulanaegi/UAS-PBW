<select name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" class="form-control" <?php echo e($required ? 'required' : ''); ?>>
    <option value=""><?php echo e($placeholder); ?></option>
    <?php echo e($slot); ?>

</select>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/components/select-option.blade.php ENDPATH**/ ?>