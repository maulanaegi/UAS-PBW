<?php if (isset($component)) { $__componentOriginala6488acc797ee40bc55ed6344dee8ea1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1 = $attributes; } ?>
<?php $component = App\View\Components\AuthLayout::resolve(['title' => 'Log In','authTitle' => 'Welcome Back!','authSubtitle' => 'Log in using your credentials to continue.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AuthLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('authFooter', null, []); ?> 
        <div class="text-center mt-4">
            <p class="text-muted">Don't have an account? <a href="<?php echo e(route('register')); ?>" class="text-primary">Sign up here</a></p>
        </div>
     <?php $__env->endSlot(); ?>

    <form action="<?php echo e(route('login')); ?>" method="POST" class="p-4 rounded shadow-sm bg-white">
        <?php echo csrf_field(); ?>
        <div class="form-group position-relative has-icon-left mb-4">
            <input type="email" name="email" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('email')); ?>" required placeholder="Email address" />
            <div class="form-control-icon">
                <i class="bi bi-envelope-fill"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('email')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('email'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>

        <div class="form-group position-relative has-icon-left mb-4">
            <input type="password" name="password"
                class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                value="<?php echo e(old('password')); ?>" placeholder="Enter your password" required />
            <div class="form-control-icon">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
            <?php if (isset($component)) { $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.invalid-feedback','data' => ['message' => $errors->first('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('invalid-feedback'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->first('password'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $attributes = $__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__attributesOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda)): ?>
<?php $component = $__componentOriginal047b9e6b24e0ccc9368cd889a0715cda; ?>
<?php unset($__componentOriginal047b9e6b24e0ccc9368cd889a0715cda); ?>
<?php endif; ?>
        </div>

        <div class="d-flex justify-content-between mb-4">
            <div>
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="remember" id="remember">
                    Remember Me
                </label>
            </div>
            </div>

        <button type="submit" class="btn btn-primary btn-lg btn-block shadow-lg mt-4">
            Log in
        </button>
    </form>

     <?php $__env->slot('authFooter', null, []); ?> 
        <div class="text-center mt-5">
            <p class="text-muted">By logging in, you agree to our <a href="<?php echo e(route('register')); ?>" class="text-primary">Register</a>.</p>
        </div>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $attributes = $__attributesOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__attributesOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1)): ?>
<?php $component = $__componentOriginala6488acc797ee40bc55ed6344dee8ea1; ?>
<?php unset($__componentOriginala6488acc797ee40bc55ed6344dee8ea1); ?>
<?php endif; ?>
<?php /**PATH D:\TUGAS KULIAH\SEMESTER 5\PBW\PROYEK UAS\Pengelolaan Mahasiswa\aplikasi-kelola-mahasiswa\resources\views/auth/login.blade.php ENDPATH**/ ?>